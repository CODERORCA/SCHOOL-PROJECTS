/*
|=======================================================================================================================|
|                                                                                                                       |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > LOGIN                                                                               |
|                                                                                                                       |
|=======================================================================================================================|
|                        |                                                                                              |
|    AUTHORS             |    Thomas Tischner                                                                           |
|                        |    Kevin M. Kiersk                                                                           |
|    DATE OF CREATION    |    March 1st, 2024                                                                           |
|    LAST UPDATE         |    March 5th, 2024                                                                           |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\login.sql                |
|                                                                                                                       |
|=======================================================================================================================|
|    login to database and protocol it with SPOOL command.                                                              |
=========================================================================================================================
*/
PROMPT ==================================================================================================================
PROMPT |                                                                                                                |
PROMPT |    LANDESWAEHRUNGEN_DB > LOGIN                                                                                 |
PROMPT |                                                                                                                |
PROMPT ==================================================================================================================

-- disable displaying contents of script files
set linesize 300
set echo OFF
CL SCR

--  enable protocolling
SPOOL C:\Users\student\Desktop\Projekt_Waehrungen\login.log

pause ENTER drücken

PROMPT Welcome to SQL*Plus

--  initiate operating system commands
host dir /p/s

--  disable protocolling
SPOOL off

set echo on