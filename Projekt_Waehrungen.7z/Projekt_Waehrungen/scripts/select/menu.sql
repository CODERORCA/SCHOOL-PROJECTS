/*
============================================================================================================
|                                                                                                          |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU                                                                   |
|                                                                                                          |
|==========================================================================================================|
|                        |                                                                                 |
|    AUTHORS             |    Thomas Tischner                                                              |
|                        |    Kevin M. Kiersk                                                              |
|    DATE OF CREATION    |    March 1st, 2024                                                              |
|    LAST UPDATE         |    March 5th, 2024                                                              |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\m.sql       |
|                        |                                                                                 |
|==========================================================================================================|
|   Main menu                                                                                              |
|   Load and create a structure or add, alter, delete and look for specific data.                          |
============================================================================================================
*/

set linesize 300
set echo OFF
CL SCR

PROMPT | X = BEENDEN | O = ZURUECK |
PROMPT =====================================================================================================
PROMPT |                                                                                                   |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE                                                                    |
PROMPT |                                                                                                   |
PROMPT |===================================================================================================|
PROMPT |         |                        |                                                                |
PROMPT |    1    |    WAEHRUNG            |    > Nach Waherungen suchen                                    |
PROMPT |    2    |    LAND                |    > Nach Laender suchen                                       |
PROMPT |    3    |                        |                                                                |
PROMPT |    4    |                        |                                                                |
PROMPT |         |                        |                                                                |
PROMPT =====================================================================================================
PROMPT
PROMPT =====================================================================================================
PROMPT |    Befehlseingabe                                                                                 |
PROMPT =====================================================================================================
ACCEPT input PROMPT "|    >> "

@&path.\select\&input..sql