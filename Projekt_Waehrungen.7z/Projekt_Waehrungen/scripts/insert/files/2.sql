/*
================================================================================================================
|                                                                                                              |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU > DATA > NEW > COUNTRY                                                |
|                                                                                                              |
|==============================================================================================================|
|                        |                                                                                     |
|    AUTHORS             |    Thomas Tischner                                                                  |
|                        |    Kevin M. Kiersk                                                                  |
|    DATE OF CREATION    |    March 1st, 2024                                                                  |
|    LAST UPDATE         |    March 5th, 2024                                                                  |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\insert\2.sql    |
|                        |                                                                                     |
|==============================================================================================================|
|   Add a new country to the database                                                                          |
================================================================================================================
*/

SET linesize 300
SET echo OFF
CL SCR

PROMPT | X = BEENDEN | Z = ZURUECK |
PROMPT =========================================================================================================
PROMPT |                                                                                                       |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE > DATENSATZ > NEU > LAND                                               |
PROMPT |                                                                                                       |
PROMPT =========================================================================================================

PROMPT
PROMPT =========================================================================================================
PROMPT |    Abgefragte Daten einfuegen                                                                         |
PROMPT =========================================================================================================
PROMPT

ACCEPT name            PROMPT                "Name des Landes | Pflichtfeld: "
ACCEPT iso             PROMPT                       "ISO-Code | Pflichtfeld: "  DEFAULT ""
ACCEPT waehrung        PROMPT              "Name der Waehrung | Pflichtfeld: "
ACCEPT gebunden        PROMPT "Gebunden an einer Leitwaehrung | optional "      DEFAULT NULL
ACCEPT leitwaehrung    PROMPT          "Name der Leitwaehrung | optional "      DEFAULT NULL

PROMPT
PROMPT =========================================================================================================
PROMPT |    Verarbeitung                                                                                       |
PROMPT =========================================================================================================
PROMPT

INSERT
    INTO    t_laender   (  name ,   iso ,    waehrung,   gebunden ,   leitwaehrung )
    VALUES              ('&name', '&iso', '&waehrung', '&gebunden', '&leitwaehrung');

PROMPT
PROMPT =========================================================================================================
PROMPT |    Ausgabe durch Befehl COMMIT                                                                        |
PROMPT =========================================================================================================
PROMPT

COMMIT;

PROMPT
PROMPT =========================================================================================================
PROMPT |    Daten eingespeisst in der Tabelle:                                                                 |
PROMPT |    LAENDER                                                                                            |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM    t_laender
        WHERE   name = '&name'
        AND     iso  = '&iso'
;
PROMPT
PROMPT =====================================================================================================
PROMPT |    Datenbank bitte neu starten                                                                    |
PROMPT =====================================================================================================
PAUSE

@&path.\menu.sql