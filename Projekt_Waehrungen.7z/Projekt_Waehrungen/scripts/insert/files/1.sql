/*
================================================================================================================
|                                                                                                              |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU > DATA > NEW > CURRENCY                                               |
|                                                                                                              |
|==============================================================================================================|
|                        |                                                                                     |
|    AUTHORS             |    Thomas Tischner                                                                  |
|                        |    Kevin M. Kiersk                                                                  |
|    DATE OF CREATION    |    March 1st, 2024                                                                  |
|    LAST UPDATE         |    March 5th, 2024                                                                  |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\insert\1.sql    |
|                        |                                                                                     |
|==============================================================================================================|
|   Add a new currency into the database.                                                                      |
================================================================================================================
*/

SET linesize 300
SET echo OFF
CL SCR

PROMPT | X = BEENDEN | Z = ZURUECK |
PROMPT =========================================================================================================
PROMPT |                                                                                                       |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE > DATENSATZ > NEU > WAEHRUNG                                           |
PROMPT |                                                                                                       |
PROMPT =========================================================================================================

PROMPT
PROMPT =========================================================================================================
PROMPT |    Abgefragte Daten einfuegen                                                                         |
PROMPT =========================================================================================================
PROMPT

ACCEPT name                PROMPT         "Name der Waehrung | Pflichtfeld: "                     
ACCEPT iso                 PROMPT                  "ISO-Code | Pflichtfeld: "       DEFAULT ""
ACCEPT haupteinheit        PROMPT "Haupteinheit der Waehrung | Pflichtfeld: "
ACCEPT untereinheit        PROMPT "Untereinheit der Waehrung | optional, NULL: "    DEFAULT NULL
ACCEPT untereinheit_alt    PROMPT "Zusaetzliche Untereinheit | optional, NULL: "    DEFAULT NULL
ACCEPT usd_wert            PROMPT       "Wert in U.S. Dollar | Pflicht "


PROMPT
PROMPT =========================================================================================================
PROMPT |    Verarbeitung                                                                                       |
PROMPT =========================================================================================================
PROMPT

INSERT
    INTO      t_waehrung (  name , iso   ,   haupteinheit ,   untereinheit ,   untereinheit_alt )
    VALUES               ('&name', '&iso', '&haupteinheit', '&untereinheit', '&untereinheit_alt');

INSERT
    INTO      t_index    (waehrung ,   iso ,  usd_wert )
    VALUES               (  '&name', '&iso', &usd_wert);

PROMPT
PROMPT =========================================================================================================
PROMPT |    Ausgabe durch Befehl COMMIT                                                                        |
PROMPT =========================================================================================================
PROMPT

COMMIT;

PROMPT
PROMPT =========================================================================================================
PROMPT |    Daten eingespeisst in der Tabelle:                                                                 |
PROMPT |    WAEHRUNG                                                                                           |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM t_waehrung
        WHERE name       = '&name'
        AND iso          = '&iso'
        AND haupteinheit = '&haupteinheit'
;

PROMPT
PROMPT =========================================================================================================
PROMPT |    INDEX                                                                                              |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM t_index
        WHERE waehrung   = '&name'
        AND iso          = '&iso'
        AND usd_wert     = '&usd_wert'
;
PROMPT
PROMPT =====================================================================================================
PROMPT |    Datenbank bitte neu starten                                                                    |
PROMPT =====================================================================================================
PAUSE

@&path.\menu.sql