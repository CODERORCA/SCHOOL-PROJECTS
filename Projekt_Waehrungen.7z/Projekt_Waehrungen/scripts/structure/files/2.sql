/*
=========================================================================================================================================================
|                                                                                                                                                       |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU > STRUCTURE > CREATE TABLE STRUCTURE                                                                           |
|                                                                                                                                                       |
|=======================================================================================================================================================|
|                        |                                                                                                                              |
|    AUTHORS             |    Thomas Tischner                                                                                                           |
|                        |    Kevin M. Kiersk                                                                                                           |
|    DATE OF CREATION    |    March 1st, 2024                                                                                                           |
|    LAST UPDATE         |    March 7th, 2024                                                                                                           |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\structure\files\2.sql                                    |
|                        |                                                                                                                              |
|=======================================================================================================================================================|
|    Load the base structure                                                                                                                            |
=========================================================================================================================================================
*/

set linesize 100
set echo OFF
CL SCR

PROMPT | X = BEENDEN | O = ZURUECK |
PROMPT ==================================================================================================================================================
PROMPT |                                                                                                                                                |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE > TABELLENSTRUKTUREN > TABELLENSTRUKTUR ERSTELLEN                                                               |
PROMPT |                                                                                                                                                |
PROMPT |================================================================================================================================================|
PROMPT |                                                                                                                                                |
PROMPT |================================================================================================================================================|
PROMPT |    Grundstruktur fuer die Waehrungen                                                                                                           |
PROMPT ==================================================================================================================================================
PROMPT

DROP TABLE t_index;
DROP TABLE t_laender;
DROP TABLE t_waehrung;

PROMPT ==================================================================================================================================================
PROMPT |    STRUKTUREN ANLEGENN                                                                                                                         |
PROMPT ==================================================================================================================================================
PROMPT

CREATE TABLE t_waehrung
(
    name                VARCHAR2(40)    CONSTRAINT pk_waehrung_name             PRIMARY KEY,
    iso                 VARCHAR2(4),
    haupteinheit        VARCHAR2(20),
    untereinheit        VARCHAR2(20),
    untereinheit_alt    VARCHAR2(20)
);

CREATE TABLE t_laender
(
    name                VARCHAR2(40)    CONSTRAINT pk_laender_name              PRIMARY KEY,
    iso                 VARCHAR2(4),
    waehrung            VARCHAR2(40)    CONSTRAINT fk_laender_waehrung          REFERENCES t_waehrung(name),
    gebunden            VARCHAR2(4),
    leitwaehrung        VARCHAR2(40)
);

CREATE TABLE t_index
(                
    iso                 VARCHAR2(4),
    waehrung            VARCHAR2(40)    CONSTRAINT fk_index_waehrung            REFERENCES t_waehrung(name),
                                        CONSTRAINT pk_index_iso_waehrung        PRIMARY KEY(iso,waehrung),
    usd_wert            number
);

PROMPT ==================================================================================================================================================
PROMPT |    STRUKTUREN ANZEIGEN                                                                                                                         |
PROMPT ==================================================================================================================================================
PROMPT

desc t_waehrung
desc t_laender
desc t_index
PROMPT
PROMPT ==================================================================================================================================================
PROMPT |    Enter zum Bestaetigen und Datenbank neustarten                                                                                              |
PROMPT ==================================================================================================================================================
PROMPT
PAUSE

@&path.\menu.sql