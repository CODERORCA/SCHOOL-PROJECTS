/*
=========================================================================================================================================================
|                                                                                                                                                       |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU > STRUCTURE > LOAD STRUCTURE                                                                                   |
|                                                                                                                                                       |
|=======================================================================================================================================================|
|                        |                                                                                                                              |
|    AUTHORS             |    Thomas Tischner                                                                                                           |
|                        |    Kevin M. Kiersk                                                                                                           |
|    DATE OF CREATION    |    March 1st, 2024                                                                                                           |
|    LAST UPDATE         |    March 7th, 2024                                                                                                           |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\structure\files\1.sql                                    |
|                        |                                                                                                                              |
|=======================================================================================================================================================|
|    Load the base structure                                                                                                                            |
=========================================================================================================================================================
*/

set linesize 300
set echo OFF
CL SCR

PROMPT ==================================================================================================================================================
PROMPT |                                                                                                                                                |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE > STRUKTUREN > GRUNDSTRUKTUR AUFRUFEN                                                                           |
PROMPT |                                                                                                                                                |
PROMPT |================================================================================================================================================|
PROMPT |                                                                                                                                                |
PROMPT |================================================================================================================================================|
PROMPT |    Grundstruktur fuer die Waehrungen                                                                                                           |
PROMPT ==================================================================================================================================================
PROMPT

INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Arabische Dirham' , 'AED' , 'Dirham' , '100 Fils' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Afghani' , 'AFN' , 'Afghani' , '100 Pul' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Lek' , 'ALL' , NULL , NULL , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Dram' , 'AMD' , 'Dram' , '100 Luma' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Antillen Gulden' , 'ANG' , 'Gulden' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kwanza' , 'AOA' , 'Kwanza' , '100 Cêntimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Argetinische Peso' , 'ARS' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Australische Dollar' , 'AUD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Gulden' , 'AWG' , 'Gulden' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Aserbaidschan Manat' , 'AZN' , 'Manat' , '100 Qəpik' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Konvertible Mark' , 'BAM' , 'Mark' , '100 Fening' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Barbados Dollar' , 'BBD' , ' Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Taka' , 'BDT' , 'Taka' , '100 Poisha' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Bulgarische Lew' , 'BGN' , 'Lew' , '100 Stotinki' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Bahrainische Dinar' , 'BHD' , 'Dinar' , '1000 Fils' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Burundische Franc' , 'BIF' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Bermuda Dollar' , 'BMD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Brunei Dollar' , 'BND' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Boliviano' , 'BOB' , 'Boliviano' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Brasilianische Real' , 'BRL' , 'Real' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Bahamas Dollar' , 'BSD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ngultrum' , 'BTN' , 'Ngultrum' , '100 Chetrum' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Pula' , 'BWP' , 'Pula' , '100 Thebe' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Belarusische Rubel' , 'BYR' , 'Rubel' , '100 Kopeken' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Belize Dollar' , 'BZD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kanadische Dollar' , 'CAD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kongolesische Franc ' , 'CDF' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'CFA-Franc' , 'CFA' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Schweizer Franken' , 'CHF' , 'Franken' , '100 Rappen' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Cook Dollar' , 'CKD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Chilenischer Peso' , 'CLP' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Renminbi Yuan' , 'CNY' , 'Yuán' , '10 Jiǎo' , '100 Fēn' );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Komumbische Peso' , 'COP' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Colon' , 'CRC' , 'Colon' , '100 Céntimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kubanische Peso' , 'CUP' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kap Verde Escudo' , 'CVE' , 'Kap Verde Escudo ' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tschechische Krone' , 'CZK' , 'Krone' , '100 Heller' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Dschibuti Franc' , 'DJF' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Daenische Krone' , 'DKK' , 'Krone' , '100 Øre' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Dominikanische Peso' , 'DOP' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Algerische Dinar' , 'DZD' , 'Dinar' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Aegyptisches Pfund' , 'EGP' , 'Pfund' , '100 Piaster' , '1000 Millièmes');
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Nakfa' , 'ERN' , 'Nakfa' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Aethiopischer Birr' , 'ETB' , 'Birr' , '100 Santim' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Euro' , 'EUR' , 'Euro' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Fidschi Dollar' , 'FJD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Falkland Pfund' , 'FKP' , 'Pfund' , '100 Pence' , NULL );  
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Faeroeer Krone' , 'FOK' , 'Krone' , '100 Oyra' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Sterling Pfund' , 'GBP' , 'Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Georgische Lari' , 'GEL' , 'Lari' , '100 Tetri' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Guernsey Pfund' , 'GGP' , 'Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ghanaische Cedi' , 'GHS' , 'Cedi' , '100 Pesewas' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Gibraltar Pfund' , 'GIP' , 'Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Delasi' , 'GMD' , 'Delasi' , '100 Bututs' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Guinea Franc' , 'GNF' , 'Franc Guineen' , NULL , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Quetzal' , 'GTQ' , 'Quetzal' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Guyana Dollar' , 'GYD' , 'Dollar ' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Hongkong Dollar' , 'HKD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Lempira' , 'HNL' , 'Lempira' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Gourde' , 'HTG' , 'Gourde' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ungarische Forint' , 'HUF' , 'Forint' , '100 Fillér' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Indonesische Rupiah' , 'IDR' , 'Rupiah' , '100 Sen' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Israelischer Schekel' , 'ILS' , 'Schekel' , '100 Agorot' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Isle Of Man Pfund' , 'IMP' , 'Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Indische Rupie' , 'INR' , 'Rupie' , '100 Paise' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Irakische Dinar' , 'IQD' , 'Dinar' , '100 Fils' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Iranische Rial' , 'IRR' , 'Rial' , '100 Dinar vormals' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Islaendische Krone' , 'ISK' , 'Krone' , '100 Aurar vormals' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Jersey Sterling Pfund' , 'JEP' , 'Jersey Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Jamaika Dollar' , 'JMD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Jordanische Dinar' , 'JOD' , 'Dinar' , '100 Piaster' , '1000 Fils' );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Japanische Yen' , 'JPY' , 'Yen' , '100 Sen' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kenianische Schilling' , 'KES' , 'Kenia Schilling' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Som' , 'KGS' , 'Som' , '100 Tyjin' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kambodschanische Riel' , 'KHR' , 'Riel' , NULL , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kiribati Dollar' , 'KID' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Komorische Franc' , 'KMF' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Nordkoreanische Won' , 'KPW' , 'Won' , '100 Chon' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Suedkoreanische Won' , 'KRW' , 'Won' , '100 Chon' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kuwait Dinar' , 'KWD' , 'Dinar' , '1000 Fils' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Cayman Dollar' , 'KYD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kasachische Tenge ' , 'KZT' , 'Tenge' , '100 Tiyn' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kip' , 'LAK' , 'Kip' , '100 Att vormals' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Libanesische Pfund' , 'LBP' , 'Pfund' , '100 Piaster' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Sri Lanka Rupie' , 'LKR' , 'Rupie' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Liberanischer Dollar' , 'LRD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Lesothische Loti' , 'LSL' , 'Loti' , '100 Lisente' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Libyscvhe Dinar' , 'LYD' , 'Dinar' , '1000 Dirham' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Marokkanische Dirham' , 'MAD' , 'Dirham' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Moldauischer Leu' , 'MDL' , 'Leu' , '100 Bani' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Madagassische Ariary' , 'MGA' , 'Ariary' , '5 Iraimbilanja' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Mazedonische Denar' , 'MKD' , 'Denar' , '100 Deni' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kyat' , 'MMK' , 'Kyat' , '100 Pya' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Toegroeg' , 'MNT' , 'Tugrik' , '100 Mongo' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Macau Pataca' , 'MOP' , 'Matau Pataca' , '100 Avos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Mauretanische Ouguiya' , 'MRU' , 'Ouguiya' , '5 Khoums' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Mauritius Rupie' , 'MUR' , 'Rupie' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Maledivische Rufiyaa' , 'MVR' , 'Rufiyaa' , '100 Laari' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Malawische Kwacha' , 'MWK' , 'Malawi Kwacha' , '100 Tambala' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Mexikanische Peso' , 'MXN' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Malaysischer Ringgit' , 'MYR' , 'Ringgit' , '100 Sen' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'neuer Metical' , 'MZN' , 'Metical' , '100 Cemtavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Namibische Dollar' , 'NAD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Naira' , 'NGN' , 'Naira' , '100 Kobi' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Cordoba Oro' , 'NIO' , 'Oro' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Norwegische Krone' , 'NOK' , 'Krone' , '100 Øre' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Nepalesische Rupie' , 'NPR' , 'Rupie' , '100 Paisa' , NULL );    
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Neuseländische Dollar' , 'NZD' , 'Dollar' , '100 Cent' , NULL );    
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Omanische Rial' , 'OMR' , 'Rial' , '1000 Baisa' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Panamaische Balboa' , 'PAB' , 'Balboa' , '100 Centésimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Peruanischer Sol' , 'PEN' , 'Nuevo Sol' , '100 Céntimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Kina' , 'PGK' , 'Kina' , '100 Toea' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Philippinische Peso' , 'PHP' , 'Peso' , '100 Centavos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Pakistanische Rupie' , 'PKR' , 'Rupie' , '100 Paise' , NULL );    
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Polnischer Zloty' , 'PLN' , 'Zloty' , '100 Groszy' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Paraguayischer Guarani' , 'PYG' , 'Guarani' , '100 Céntimos' , NULL );    
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Qatar Rial' , 'QAR' , 'Riyal' , '100 Dirham' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Rumaenische Leu ' , 'RON' , 'Leu' , '100 Bani' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Serbische Dinar' , 'RSD' , 'Dinar' , '100 Para' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Russischer Rubel' , 'RUB' , 'Rubel' , '100 Kopeken' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ruandische Franc' , 'RWF' , 'Franc' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Saudische Rial' , 'SAR' , 'Saudi Riyal' , '20 Qurusch' , '100 Halala' );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Salomonische Dollar' , 'SBD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Seychellen Rupie' , 'SCR' , 'Rupie' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Sudanesische Pfund' , 'SDG' , 'Pfund' , '100 Piaster' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Schwedische Krone' , 'SEK' , 'Krone' , '100 Oere' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Singapur Dollar' , 'SGD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'St Helena Pfund' , 'SHP' , 'Pfund' , '100 Pence' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Leone' , 'SLL' , 'Leone' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Somalische Schilling' , 'SOS' , 'Schilling ' , '100 Centesimi' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Surinamische Dollar' , 'SRD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Suedsudanesische Pfund' , 'SSP' , 'Pfund' , '100 Piaster' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Dobra' , 'STD' , 'Dobra' , '100 Cêntimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Syrisches Pfund' , 'SYP' , 'Lira' , '100 Piaster' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Swazi Lilangeni' , 'SZL' , 'Lilangeni' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Thailaendische Baht' , 'THB' , 'Baht' , '100 Satang' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Somoni' , 'TJS' , 'Somoni' , '100 Diram' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Turkmenische Manat' , 'TMT' , 'Manat' , '100 Teňňe' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tunesische Dinar' , 'TND' , 'Dinar' , '1000 Millimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Paanga' , 'TOP' , 'Dollar' , '100 Seniti' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tuerkische Lira' , 'TRY' , 'Lira' , '100 Kurus' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Trinidad u Tobago Dollar' , 'TTD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tuvaluischer Dollar' , 'TVD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Neuer Taiwan Dollar' , 'TWD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tansanische Schilling' , 'TZS' , ' Schilling' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Hrywnja' , 'UAH' , 'Hrywnja' , '100 Kopijok' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ugandische Schilling' , 'UGX' , ' Schilling' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Amerikanische Dollar' , 'USD' , ' Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Uruguayische Peso' , 'UYU' , 'Peso' , '100 Centésimos' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Uzbekische Som' , 'UZS' , 'Som' , '100 Tiyin' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Bolivar digital' , 'VED' , 'Bolivar' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Vietnamesischer Dong' , 'VND' , 'Dong' , '10 Hào' , '100 Xu' );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Vatu' , 'VUV' , 'Vatu' , '100 Centimes' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Tala' , 'WST' , 'Tala' , '100 Seng' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Ostkaribische Dollar' , 'XCD' , 'Dollar' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Pazifische Franc' , 'XPF' , 'Franc' , '100 Centime' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Jementische Rial' , 'YER' , 'Rial' , '100 Fils' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Suedafrikan Rand' , 'ZAR' , 'Rand' , '100 Cent' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Sambische Kwacha' , 'ZMW' , 'Kwacha' , '100 Ngwee' , NULL );
INSERT
    INTO t_waehrung ( name , iso , haupteinheit , untereinheit , untereinheit_alt )
    VALUES          ( 'Simbabwe Dollar' , 'ZWL' , 'Dollar' , '100 Cent' , NULL );

PROMPT ==================================================================================================================================================
PROMPT |    Grundstruktur fuer die Laender                                                                                                              |
PROMPT ==================================================================================================================================================
PROMPT
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Vereinigte Arabische Emirate' , 'AED' , 'Arabische Dirham' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Afghanistan' , 'AFG' , 'Afghani' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Albanien' , 'ALB' , 'Lek' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Armenien' , 'ARM' , 'Dram' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sint Maarten' , 'SMX' , 'Antillen Gulden' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Curaçao' , 'CUW' , 'Antillen Gulden' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Angola' , 'AGO' , 'Kwanza' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Argentinien' , 'ARG' , 'Argetinische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Australien' , 'AUS' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Weihnachtsinsel' , 'CXR' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kokoinsel' , 'CCK' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nauru'  , 'NRU' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Norfolkinsel' , 'NFK' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Heard'  , 'HMD' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'McDonald Inseln' , 'HMD' , 'Australische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Aruba' , 'ABW' , 'Gulden' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Aserbaidschan' , 'AZE' , 'Aserbaidschan Manat' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bosnien und Herzegowina' , 'BIH' , 'Konvertible Mark' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Barbados' , 'BRB' , 'Barbados Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bangladesch' , 'BGD' , 'Taka' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bulgarien' , 'BGR' ,'Bulgarische Lew' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bahrain' , 'BHR' , 'Bahrainische Dinar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Burundi' , 'BDI' , 'Burundische Franc' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bermuda' , 'BMU' , 'Bermuda Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Brunei' , 'BRN' , 'Brunei Dollar' , 'ja' , 'SGD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bolivien' , 'BOL' , 'Boliviano' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Brasilien' , 'BRA' , 'Brasilianische Real' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bahamas' , 'BHS' , 'Bahamas Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bhutan' , 'BTN' , 'Ngultrum' , 'ja' , 'INR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Botswana' , 'BWA' , 'Pula' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Belarus' , 'BLR' , 'Belarusische Rubel' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Belize' , 'BLZ' , 'Belize Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kanada' , 'CAN' , 'Kanadische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Demokratische Republik Kongo' , 'COD' , 'Kongolesische Franc' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Benin'  , 'BEN' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Burkina Faso' , 'BFA' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Elfenbeinkueste ', 'CIV' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Gibraltar', 'GIB' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guinea-Bissau' , 'GNB' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Burkina Faso', 'BFA' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Gabun', 'GAB' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guinea-Bissau', 'GNB' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kamerun', 'CMR' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mali', 'MLI' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Niger', 'NER' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Republik Kongo', 'COG' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Senegel', 'SEN' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Togo', 'TGO' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tschad', 'TCD' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Zentralafr. Republik', 'CAF' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Aequatorialguinea', 'GNQ' , 'CFA-Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Liechtenstein', 'LIE' , 'Schweizer Franken' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Schweiz', 'CHE' , 'Schweizer Franken' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Cookinseln', 'COK' , 'Cook Dollar' , 'ja' , 'NZD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Chile', 'CHL' , 'Chilenischer Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'China', 'CHN' , 'Renminbi Yuan' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kolumbien', 'COL' , 'Komumbische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Costa Rica', 'CRI' , 'Colon' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kuba', 'CUP' , 'Kubanische Peso' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kap Verde', 'CPV' , 'Kap Verde Escudo' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tschechien', 'CZE' , 'Tschechische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Dschibuti', 'DJI' , 'Dschibuti Franc' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Groenland', 'GRL' , 'Daenische Krone' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Daenemark', 'DNK' , 'Daenische Krone' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Dominikanische Rep.', 'DOM' , 'Dominikanische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Algerien', 'DZA' , 'Algerische Dinar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Aegypten', 'EGY' , 'Aegyptisches Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Eritrea', 'ERI' , 'Nakfa' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Aethiopien', 'ETH' , 'Aethiopischer Birr' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Niederlande', 'NLD' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Andorra', 'AND' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Belgien', 'BEL' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Spanien', 'ESP' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guadeloupe', 'GLP' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Irland', 'IRL' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Italien', 'ITA' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Oesterreich', 'AUT' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Griechenland', 'GRC' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kroatien', 'HRV' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Zypern', 'CYP' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Lettland', 'LVA' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Litauen', 'LTU' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Luxembourg', 'LUX' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Malta', 'MLT' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Martinique', 'MTQ' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mayotte', 'MYT' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Monaco', 'MCO' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Portugal', 'PRT' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Frankreich', 'FRA' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Franz.-Guayana', 'GUF' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Reunion', 'REU' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'St. Pierre u. Miquelon', 'SPM' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Deutschland', 'DEU' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'San Marino', 'SMR' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Slowakai', 'SVK' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Slowenien', 'SVN' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Finnland', 'FIN' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Vatikanstadt', 'VAT' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Estland', 'EST' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Franz. Sued- u. Antarktikgebiete', 'ATF' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Montenegro', 'MNE' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Saint-Barthelemy', 'BLM' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kosovo', NULL , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Alandinsel', 'ALA' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Saint Martin', 'MAF' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Fidschi', 'FJI' , 'Fidschi Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Falklansinseln', 'FLK' , 'Falkland Pfund' , 'ja' , 'GBP' );  
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Faeroer', 'FRO' , 'Faeroeer Krone' , 'ja' , 'DKK' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Vereinigtes Koenigreich', 'UK' , 'Sterling Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suedgeorgien', 'SGS' , 'Sterling Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suedl. Sandwichinseln', 'SGS' , 'Sterling Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Georgien', 'GEO' , 'Georgische Lari' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guernsey', 'GGY' , 'Guernsey Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ghana', 'GHA' , 'Ghanaische Cedi' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Gibraltar', 'GIB' , 'Gibraltar Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Gambia', 'GMB' , 'Delasi' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guinea', 'GIN' , 'Guinea Franc' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guatemala' , 'GTM' , 'Quetzal' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guyana', 'GUY' , 'Guyana Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Hongkong', 'HKG' , 'Hongkong Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Honduras' , 'HND' , 'Lempira' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Haiti' , 'HTI' , 'Gourde' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ungarn', 'HUN' , 'Ungarische Forint' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Indonesien', 'IDN' , 'Indonesische Rupiah' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Israel', 'ISR' , 'Israelischer Schekel' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Palaestina', 'ISR' , 'Israelischer Schekel' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Isle of Man' , 'IMN' , 'Isle Of Man Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Indien', 'IND' , 'Indische Rupie' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Irak', 'IRQ' , 'Irakische Dinar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Iran', 'IRN' , 'Iranische Rial' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Island', 'ISL' , 'Islaendische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jersey', 'JEY' , 'Jersey Sterling Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jamaika', 'JAM' , 'Jamaika Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jordanien', 'JOR' , 'Jordanische Dinar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Japan' , 'JPN' , 'Japanische Yen' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kenia', 'KEN' , 'Kenianische Schilling' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kirgisistan' , 'KGZ' , 'Som' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kambodscha', 'KHM' , 'Kambodschanische Riel' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kiribati', 'KIR' , 'Kiribati Dollar' , 'ja' , 'AUD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Komoren', 'COM' , 'Komorische Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nordkorea', 'PRK' , 'Nordkoreanische Won' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suedkorea', 'KOR' , 'Suedkoreanische Won' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kuwait', 'KWT' , 'Kuwait Dinar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Caymanislands', 'CYM' , 'Cayman Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Kasachstan', 'KAZ' , 'Kasachische Tenge' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Laos' , 'LAO' , 'Kip' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Libanon', 'LAO' , 'Libanesische Pfund' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sri Lanka', 'LKA' , 'Sri Lanka Rupie' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Liberia', 'LBR' , 'Liberanischer Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Lesotho', 'LSO' , 'Lesothische Loti' , 'ja' , 'ZAR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Libyen', 'LBY' , 'Libysche Dinar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Westsahara', 'ESH' , 'Marokkanische Dirham' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Marokko', 'MAR' , 'Marokkanische Dirham' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Moldau', 'MDA' , 'Moldauischer Leu' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Madagaskar', 'MDG' , 'Madagassische Ariary' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nordmazedonien', 'MKD' , 'Mazedonische Denar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Myanmar', 'BUR' , 'Kyat' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mongolei' , 'MNG' , 'Toegroeg' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Macau', 'MAC' , 'Macau Pataca' , 'ja' , 'HKD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mauretanien', 'MRT' , 'Mauretanische Ouguiya' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mauritius', 'MUS' , 'Mauritius Rupie' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Malediven', 'MDV' , 'Maledivische Rufiyaa' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Malawi', 'MWI' , 'Malawische Kwacha' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mexiko', 'MEX' , 'Mexikanische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Malaysia', 'MYS' , 'Malaysischer Ringgit' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mosambik', 'MOZ' , 'neuer Metical' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Namibia', 'NAM' , 'Namibische Dollar' , 'ja' , 'ZAR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nigeria', 'NGA' , 'Naira' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nicaragua', 'NIC' , 'Cordoba Oro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Spitzbergen', 'SJM' , 'Norwegische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jan Mayen', 'SJM' , 'Norwegische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Norwegen', 'NOR' , 'Norwegische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Bouvetinsel', 'BVT' , 'Norwegische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nepal', 'NPL' , 'Nepalesische Rupie' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Niue', 'NIU' , 'Neuselaendische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Pitcairninseln', 'PCN' , 'Neuselaendische Dollar' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tokelau', 'TKL' , 'Neuselaendische Dollar' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Neuseeland', 'NZL' , 'Neuselaendische Dollar' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Oman', 'OMN' , 'Omanische Rial' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Panama', 'PAN' , 'Panamaische Balboa' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Peru', 'PER' , 'Peruanischer Sol' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Papua-Neuguinea', 'PNG' , 'Kina' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Philippinen', 'PHL' , 'Philippinische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Pakistan', 'PAK' , 'Pakistanische Rupie' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Polen', 'POL' , 'Polnischer Zloty' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Paraguay', 'PRY' , 'Paraguayischer Guarani' , NULL , NULL );    
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Katar', 'QAT' , 'Qatar Rial' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Rumaenien', 'ROU' , 'Rumaenische Leu' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Serbien', 'SRB' , 'Serbische Dinar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Russland', 'RUS' , 'Russischer Rubel' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ruanda', 'RWA' , 'Ruandische Franc' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Saudi-Arabien', 'SAU' , 'Saudische Rial' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Salomonen', 'SLB' , 'Salomonische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Seychellen', 'SYC' , 'Seychellen Rupie' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sudan', 'SDN' , 'Sudanesische Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Schweden', 'SWE' , 'Schwedische Krone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Singapur', 'SGP' , 'Singapur Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'St. Helena', 'SHN' , 'St Helena Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ascension ', 'SHN' , 'St Helena Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tristan da Cunha', 'SHN' , 'St Helena Pfund' , 'ja' , 'GBP' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sierra Leone', 'SLE' , 'Leone' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Somalia', 'SOM' , 'Somalische Schilling' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suriname', 'SUR' , 'Surinamische Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suedsudan', 'SSD' , 'Suedsudanesische Pfund' , 'ja' , 'SDG' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sao Tome und Principe', 'STP' , 'Dobra' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Syrien', 'SYR' , 'Syrisches Pfund' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Eswatini', 'SWZ' , 'Swazi Lilangeni' , 'ja' , 'ZAR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Thailand', 'THA' , 'Thailaendische Baht' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tadschikistan' , 'TJK' , 'Somoni' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Turkmenistan', 'TKM' , 'Turkmenische Manat' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tunesien', 'TUN' , 'Tunesische Dinar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tonga' , 'TON' , 'Paanga' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tuerkei', 'TUR' , 'Tuerkische Lira' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Trinidad u. Tobago' , 'TTO' , 'Trinidad u Tobago Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tuvalu', 'TUV' , 'Tuvaluischer Dollar' , 'ja' , 'AUD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Taiwan', 'TWN' , 'Neuer Taiwan Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Tansania', 'TZA' , 'Tansanische Schilling' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ukraine' , 'UKR' , 'Hrywnja' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Uganda', 'UGA' , 'Ugandische Schilling' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'USA' , 'USA' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Amerk. Samoa' , 'ASM' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jungferninseln (UK)' , 'VGB' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Ecuador' , 'ECU' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'El Salvador' , 'SLV' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Guam' , 'GUM' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Osttimor' , 'TLS' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Marshallinseln' , 'MHL' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Mikronesien' , 'FSM' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Palau' , 'PLW' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Noerd. Marianen' , 'MNP' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Puerto Rico' , 'PRI' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Turks ' , 'TCA' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Caicosinseln' , 'TCA' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jungferninseln (US)' , 'ISV' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Brit. Territorium (Ind. Ozean)' , 'IOT' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Karib. Niederlande' , 'NLD' , 'Euro' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Inseln der USA' , 'USA' , 'US Dollar' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Uruguay', 'URY' , 'Uruguayische Peso' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Usbekistan', 'UZB' , 'Uzbekische Som' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Venezuela' , 'VEN' , 'Bolivar digital' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Vietnam', 'VNM' , 'Vietnamesischer Dong' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Vanuatu', 'VUT' , 'Vatu' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Samoa', 'WSM' , 'Tala' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Anguilla', 'AIA' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Antigua', 'ATG' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Barbuda', 'ATG' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Dominica', 'DMA' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Grenada', 'GRD' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Montserrat', 'MSR' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'St. Kitts', 'KNA' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Nevis', 'KNA' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'St. Lucia', 'LCA' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'St. Vincent', 'VCT' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Grenadinen', 'VCT' , 'Ostkaribische Dollar' , 'ja' , 'USD' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Franz.-Polynesien', 'PYF' , 'Pazifische Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Neukaledonien', 'NCL' , 'Pazifische Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Wallis', 'WLF' , 'Pazifische Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Futuna', 'WLF' , 'Pazifische Franc' , 'ja' , 'EUR' );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Jemen', 'YEM' , 'Jementische Rial' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Suedafrika', 'ZAF' , 'Suedafrikan Rand' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Sambia', 'ZMB' , 'Sambische Kwacha' , NULL , NULL );
INSERT
    INTO t_laender ( name , iso , waehrung , gebunden , leitwaehrung )
    VALUES         ( 'Simbabwe', 'ZWE' , 'Simbabwe Dollar' , NULL , NULL );

PROMPT ==================================================================================================================================================
PROMPT |    Grundstruktur fuer den Index                                                                                                                |
PROMPT ==================================================================================================================================================
PROMPT

INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AED' , 'Arabische Dirham' ,  0.2700);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AFN' , 'Afghani' , 0.0140);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ALL' , 'Lek' , 0.0110 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AMD' , 'Armenischer Dram' , 0.0025 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ANG' , 'Antillen Gulden', 0.5600 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AOA' , 'Kwanza' , 0.0012 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ARS' , 'Argetinische Peso' , 0.0012 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AUD' , 'Australische Dollar' , 0.6600 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AWG' , 'Gulden' ,  0.00027);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'AZN' , 'Aserbaidschan Manat' ,  0.5900);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BAM' , 'Konvertible Mark' , 0.6300  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BBD' , 'Barbados Dollar' , 0.5000 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BDT' , 'Taka' , 0.0091 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BGN' , 'Bulgarische Lew' , 0.5600 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BHD' , 'Bahrainische Dinar' , 2.65957 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BIF' , 'Burundische Franc' , 0.00035 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BMD' , 'Bermuda Dollar' , 1.0 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BND' , 'Brunei Dollar' , 0.7500 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BOB' , 'Boliviano' , 0.1400 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BRL' , 'Brasilianische Real' , 0.2000);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BSD' , 'Bahamas Dollar' , 1.0015 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BTN' , 'Ngultrum' , 0.0150 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BWP' , 'Pula' , 0.07335 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BYR' , 'Belarusische Rubel' , NULL );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'BZD' , 'Belize Dollar' , 0.2800  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CAD' , 'Kanadische Dollar' , 0.7400 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CDF' , 'Kongolesische Franc' , 0.00062 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          (  'CFA' , 'CFA-Franc' ,  0.0017);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          (  'CHF' , 'Schweizer Franken' , 1.1351 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NZD' , 'Cook Dollar' , 0.6160  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CLP' , 'Chilenischer Peso' , 0.0010 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CNY' , 'Renminbi Yuan' ,  0.1400);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'COP' , 'Komumbische Peso' ,0.00026  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CRC' , 'Colon' , 0.0020 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CUP' , 'Kubanische Peso' ,0.0420  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CVE' , 'Kap Verde Escudo' , 0.0099 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'CZK' , 'Tschechische Krone' , 0.0430 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'DJF' , 'Dschibuti Franc' ,0.0056  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'DKK' , 'Daenische Krone' , 0.1500 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'DOP' , 'Dominikanische Peso' ,  0.0170);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'DZD' , 'Algerische Dinar' ,  0.0074);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'EGP' , 'Aegyptisches Pfund' ,0.0200  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ERN' , 'Nakfa' , 0.06666 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ETB' , 'Aethiopischer Birr' , 0.0180 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'EUR' , 'Euro' , 1.0902 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'FJD' , 'Fidschi Dollar' , 0.4481  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'FKP' , 'Falkland Pfund' , 1.2760 );  
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'FOK' , 'Faeroeer Krone' , 1.2745 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GBP' , 'Sterling Pfund' ,1.2753  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GEL' , 'Georgische Lari' , 0.3800 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GGP' , 'Guernsey Pfund' , 1.2760 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GHS' , 'Ghanaische Cedi' , 0.07841  );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GIP' , 'Gibraltar Pfund' , 1.2745 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GMD' , 'Delasi' , 0.0150 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GNF' , 'Guinea Franc' , 0.00012 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GTQ' , 'Quetzal' , 0.1300 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'GYD' , 'Guyana Dollar' , 0.0048 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'HKD' , 'Hongkong Dollar' , 0.1300);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'HNL' , 'Lempira' , 0.0410 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'HTG' , 'Gourde' , 0.0076 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'HUF' , 'Ungarische Forint ', 0.0028 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'IDR' , 'Indonesische Rupiah' , 0.000064 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ILS' , 'Israelischer Schekel' , 0.2800 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'IMP' , 'Isle Of Man Pfund', 1.2760 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'INR' , 'Indische Rupie' , 0.0120);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'IQD' , 'Irakische Dinar' , 0.0007653 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'IRR' , 'Iranische Rial' , 0.000024 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ISK' , 'Islaendische Krone' ,0.0073);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'JEP' , 'Jersey Sterling Pfund' , 1.2760 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'JMD' , 'Jamaika Dollar' , 0.0073 ); 
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'JOD' , 'Jordanische Dinar' , 1.41064);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'JPY' , 'Japanische Yen' ,0.0068 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KES' , 'Kenianische Schilling' ,0.0070 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KGS' , 'Som' , 0.0150 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KHR' , 'Kambodschanische Riel' , 0.00025);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'FKP' , 'Kiribati Dollar' , 1.2760 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KMF' , 'Komorische Franc' , 0.0022);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KPW' , 'Nordkoreanische Won' , 0.001111 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KRW' , 'Suedkoreanische Won' , 0.00075);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KWD' , 'Kuwait Dinar' , 3.25415);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KYD' , 'Cayman Dollar' , 1.21951 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'KZT' , 'Kasachische Tenge' , 0.0022);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LAK' , 'Kip' ,0.0001 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LBP' , 'Libanesische Pfund' , 0.000011);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LKR' , 'Sri Lanka Rupie' , 0.0033);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LRD' , 'Liberanischer Dollar' , 0.0052);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LSL' , 'Lesothische Loti' , 0.0052);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'LYD' , 'Libysche Dinar' ,0.2100 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MAD' , 'Marokkanische Dirham' , 0.1000);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MDL' , 'Moldauischer Leu' , 0.0560);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MGA' , 'Madagassische Ariary' , 0.00022);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MKD' , 'Mazedonische Denar' , 0.0180);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MMK' , 'Kyat' , 0.00048);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MNT' , 'Toegroeg' , 0.0002954 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MOP' , 'Macau Pataca' ,0.1200 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MRU' , 'Mauretanische Ouguiya' , 0.0017 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MUR' , 'Mauritius Rupie' , 0.0220);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MVR' , 'Maledivische Rufiyaa' , 0.0650 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MWK' , 'Malawische Kwacha' , 0.0006);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MXN' , 'Mexikanische Peso' , 0.0590);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MYR' , 'Malaysischer Ringgit' ,0.2100 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'MZN' , 'neuer Metical' , 0.0170);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NAD' , 'Namibische Dollar' ,0.0520 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NGN' , 'Naira' , 0.00063);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NIO' , 'Cordoba Oro' ,0.0270 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NOK' , 'Norwegische Krone' ,0.0960 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NPR' , 'Nepalesische Rupie' , 0.0076);    
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'NZD' , 'Neuselaendische Dollar' , 0.6200);    
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'OMR' , 'Omanische Rial' ,2.5974 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PAB' , 'Panamaische Balboa' ,1.0015 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PEN' , 'Peruanischer Sol' , 0.2700);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PGK' , 'Kina' , 0.2651 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PHP' , 'Philippinische Peso' ,0.0180 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PKR' , 'Pakistanische Rupie' , 0.0036);    
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PLN' , 'Polnischer Zloty' , 0.2500);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'PYG' , 'Paraguayischer Guarani' , 0.00014);    
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'QAR' , 'Qatar Rial' , 0.2700);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'RON' , 'Rumaenische Leu' , 0.1500 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'RSD' , 'Serbische Dinar' , 0.009297);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'RUB' , 'Russischer Rubel' , 0.0110);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'RWF' , 'Ruandische Franc' , 0.00078);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SAR' , 'Saudische Rial' ,0.2700 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SBD' , 'Salomonische Dollar' , 5.03551);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SCR' , 'Seychellen Rupie' , 0.0740);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SDG' , 'Sudanesische Pfund', 0.0180);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SEK' , 'Schwedische Krone' , 0.0970);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SGD' , 'Singapur Dollar' , 0.7500);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SHP' , 'St Helena Pfund' , 1.2759);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SLL' , 'Leone' , 0.00013);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SOS' , 'Somalische Schilling' ,0.0018 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SRD' , 'Surinamische Dollar' , 0.0280);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SSP' , 'Suedsudanesische Pfund' , NULL );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'STD' , 'Dobra' , NULL );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SYP' , 'Syrisches Pfund' , 0.00007691 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'SZL' , 'Swazi Lilangeni' ,0.0530 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'THB' , 'Thailaendische Baht' , 0.0280 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TJS' , 'Somoni' , 0.0920);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TMT' , 'Turkmenische Manat' ,0.2900 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TND' , 'Tunesische Dinar' , 0.32);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TOP' , 'Paanga' , 0.4223);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TRY' , 'Tuerkische Lira' , 0.0313 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TTD' , 'Trinidad u Tobago Dollar' ,0.1476 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TVD' , 'Tuvaluischer Dollar' , 0.6607); 
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TWD' , 'Neuer Taiwan Dollar' , 0.0317);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'TZS' , 'Tansanische Schilling' , 0.000392);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'UAH' , 'Hrywnja' , 0.0262);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'UGX' , 'Ugandische Schilling' , 0.0002561);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'USD' , 'US Dollar' ,  1.0);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'UYU' , 'Uruguayische Peso' , 0.0256);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'UZS' , 'Uzbekische Som' , 0.00007962);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'VED' , 'Bolivar digital' ,0.0098 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'VND' , 'Vietnamesischer Dong' ,0.00004051 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'VUV' , 'Vatu' ,0.008326 );
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'WST' , 'Tala' , 0.3640);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'XCD' , 'Ostkaribische Dollar' , 0.3701);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'XPF' , 'Pazifische Franc' , 0.0091);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'YER' , 'Jementische Rial' , 0.003994);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ZAR' , 'Suedafrikan Rand' , 0.05322);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ZMW' , 'Sambische Kwacha' , 0.04136);
INSERT
    INTO t_index    (  iso  , waehrung , usd_wert )
    VALUES          ( 'ZWL' , 'Simbabwe Dollar' , 0.00005983);

PROMPT
PROMPT ==================================================================================================================================================
PROMPT |    Enter zum Bestaetigen und Datenbank neustarten                                                                                              |
PROMPT ==================================================================================================================================================
PROMPT
PAUSE

@&path.\menu.sql