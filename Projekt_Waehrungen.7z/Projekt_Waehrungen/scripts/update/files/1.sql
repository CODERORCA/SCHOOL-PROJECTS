/*
================================================================================================================
|                                                                                                              |
|    PROJEKT_WAEHRUNGEN > SCRIPTS > MENU > DATA > UPDATE > CURRENCY                                            |
|                                                                                                              |
|==============================================================================================================|
|                        |                                                                                     |
|    AUTHORS             |    Thomas Tischner                                                                  |
|                        |    Kevin M. Kiersk                                                                  |
|    DATE OF CREATION    |    March 1st, 2024                                                                  |
|    LAST UPDATE         |    March 5th, 2024                                                                  |
|    DIRECTORY           |    @C:\Users\student\Desktop\the_project\Projekt_Waehrungen\scripts\update\1.sql    |
|                        |                                                                                     |
|==============================================================================================================|
|   Update a currency                                                                                          |
================================================================================================================
*/

SET linesize 300
SET echo OFF
CL SCR

PROMPT =========================================================================================================
PROMPT |                                                                                                       |
PROMPT |    LANDESWAEHRUNGEN_DB > MENUE > DATENSATZ > AENDERN > WAEHRUNG                                       |
PROMPT |                                                                                                       |
PROMPT |=======================================================================================================|
PROMPT

PROMPT =========================================================================================================
PROMPT |    Name der Waehrung                                                                                   |
PROMPT =========================================================================================================
PROMPT

ACCEPT name PROMPT "    | "

PROMPT
PROMPT =========================================================================================================
PROMPT |    Ausgewaehlte Dateien                                                                               |
PROMPT |=======================================================================================================|
PROMPT |    WAEHRUNG                                                                                           |
PROMPT |    Hinsweis: Name der Waehrung laesst sich aufgrund der PK Beziehung nicht aendern                    |
PROMPT |    Zum Aendern des Namens muss die Waehrung geloescht und neu aufgesetzt werden                       |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM t_waehrung
    WHERE name = '&name';

PROMPT =========================================================================================================
PROMPT |    Neue Daten eingeben | Alles optional                                                               |
PROMPT =========================================================================================================
PROMPT

ACCEPT iso                  PROMPT "ISO-Code der Waehrung: "
ACCEPT haupteinheit         PROMPT "Haupteinheit: "
ACCEPT untereinheit         PROMPT "Untereinheit: "                 DEFAULT NULL
ACCEPT untereinheit_alt     PROMPT "Zusaetzliche Untereinheit: "    DEFAULT NULL
ACCEPT usd_wert             PROMPT "Wert in U.S. Dollar: "

/*
================================================================================================================
|    Aenderung der Daten                                                                                       |
================================================================================================================
*/

UPDATE t_waehrung
    SET   iso              = '&iso',
          haupteinheit     = '&haupteinheit',
          untereinheit     = '&untereinheit',
          untereinheit_alt = '&untereinheit_alt'
    WHERE name             = '&name'
;

UPDATE t_index
    SET   iso              = '&iso',
          usd_wert         =  &usd_wert
    WHERE waehrung         = '&name'
;

PROMPT =========================================================================================================
PROMPT |    Ausfuehren durch Befehl COMMIT                                                                     |
PROMPT =========================================================================================================
PROMPT

COMMIT;

PROMPT =========================================================================================================
PROMPT |    Geandert in der Tabelle:                                                                           |
PROMPT |    WAEHRUNG                                                                                           |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM t_waehrung
    WHERE name = '&name';

PROMPT =========================================================================================================
PROMPT |    INDEX                                                                                              |
PROMPT =========================================================================================================
PROMPT

SELECT *
    FROM t_index
    WHERE waehrung = '&name';

PROMPT
PROMPT =====================================================================================================
PROMPT |    Datenbank bitte neu starten                                                                    |
PROMPT =====================================================================================================
PAUSE

@&path.\menu.sql